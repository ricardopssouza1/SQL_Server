﻿-- ============================================
-- Habilitando CLR
-- ============================================
sp_configure 'clr enable', 1
GO
RECONFIGURE
GO

-- ============================================
--  Essa propriedade está relacionado ao nível 
-- de confiabilidade com a instância. Esta 
-- opção serve para alguns acontecimentos como 
-- utilização de assemblies com EXTERNAL_ACCESS 
-- / UNSAFE e requisições que utilizam de grande 
-- privilêgio para ser executada. Todas as 
-- requisições que exijam um grande nível de 
-- confiança para ser executada em outro escopo 
-- por padrão não terá permissão
-- ============================================
ALTER DATABASE BANCO_DADOS SET TRUSTWORTHY ON
GO
-- ============================================
-- Importando o CLR para o banco
-- OBS: o caminho é onde está instalado a 
-- instância do SQL SERVER
-- ============================================
CREATE ASSEMBLY clr_sqlFTP
AUTHORIZATION dbo
FROM 'C:\TEMP\bin\sqlFTP.dll'
WITH PERMISSION_SET = UNSAFE
GO

-- ============================================
-- Criando a Procedure para Download
-- ============================================
CREATE PROCEDURE USP_ftpDownloadCLR
@ftp_server nvarchar(MAX),
@ftp_user nvarchar(MAX),
@ftp_pwd nvarchar(MAX),
@local_file nvarchar(MAX),
@rmt_file nvarchar(MAX),
@ftp_mode nvarchar(MAX),
@result nvarchar(MAX) OUTPUT

AS EXTERNAL NAME clr_sqlFTP.[sqlFTP.FTP].ftpDownload

GO

-- ============================================
-- Criando a Procedure para Upload
-- ============================================
CREATE PROCEDURE USP_ftpUploadCLR
@ftp_server_and_File nvarchar(MAX),
@ftp_user nvarchar(MAX),
@ftp_pwd nvarchar(MAX),
@local_file nvarchar(MAX),
@ftp_mode nvarchar(MAX),
@result nvarchar(MAX) OUTPUT

AS EXTERNAL NAME clr_sqlFTP.[sqlFTP.FTP].ftpUpload

GO

-- ============================================
-- Exemplo de como utilizar
-- ============================================
Declare @retorno nvarchar(MAX)
EXEC ftpUploadCLR
 @ftp_server_and_File = 'ftp.xxxxx.com.br'
,@ftp_user = 'usuario_ftp'
,@ftp_pwd = 'senha_ftp'
,@local_file = 'C:\TEMP\PastaComZip\teste.zip'
,@ftp_mode = 'teste.zip'
,@result = @retorno




